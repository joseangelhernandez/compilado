import{aF as s}from"./index-6542db70.js";const n=o=>s.post("/api/Room",o),r=()=>s.get("/api/Room"),p=()=>s.get("/api/Room/GetAllAsignedRooms");export{p as a,n as c,r as g};
