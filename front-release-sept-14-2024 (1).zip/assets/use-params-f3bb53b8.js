import{by as s,r as a}from"./index-6542db70.js";function o(){const r=s();return a.useMemo(()=>r,[r])}export{o as u};
