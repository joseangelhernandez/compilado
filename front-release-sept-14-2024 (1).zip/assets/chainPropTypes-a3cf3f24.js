function e(p,r){return()=>null}export{e as c};
