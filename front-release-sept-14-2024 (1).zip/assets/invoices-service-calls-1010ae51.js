import{aF as e}from"./index-6542db70.js";const i=async()=>await e.get("/api/Invoice/Invoice"),t=async s=>await e.get(`/api/Invoice/List/AdmissionId?id=${s}`);export{t as a,i as g};
