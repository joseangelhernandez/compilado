import{dn as t}from"./index-6542db70.js";const a=t(),o=a;export{o as S};
